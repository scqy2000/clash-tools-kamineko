import{V as a,b2 as m}from"./index-BKz6pv0O.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
